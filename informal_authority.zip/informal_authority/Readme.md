# Docker

1. 包含docker-compose文件
2. 上传到lee@school:/home/lee/oTree
2.1 entrypoint.sh和pg_ping.py要chmod +x

3. 关闭并清除数据 docker-compose down -v
4. 开放 docker-compose up

# 结构

# 第一阶段：身份决定
## 三个treatment
1. IdentityChoiceColor: IdentityChoiceBase

2. IdentityChoiceWl: IdentityChoiceBase

3.1 IdentityCompeteIntro
3.2 IdentityCompeteGame

# 第二阶段：工作协作

1. CoordinationTest
2.1 CoordinationChoice_01 : CoordinationChoiceBase
2.1 CoordinationChoice_02 : CoordinationChoiceBase
2.1 CoordinationChoice_03 : CoordinationChoiceBase
2.1 CoordinationChoice_04 : CoordinationChoiceBase
2.1 CoordinationChoice_05 : CoordinationChoiceBase
3. CoordinationResult :

